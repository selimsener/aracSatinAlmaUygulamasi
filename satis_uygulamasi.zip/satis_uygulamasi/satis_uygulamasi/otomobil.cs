﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace satis_uygulamasi
{
    public partial class otomobil : Form
    {
        public otomobil()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localhost; port=5433; Database=satis_uygulamasi; user Id=postgres; password=selim2002");
        private void button1_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from otomobil";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds;
            dataGridView1.DataSource = ds.Tables[0];

        }

        private void otoEkle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand ekle1 = new NpgsqlCommand("insert into otomobil(marka,model,yakit,vites,renk,tur,durum,fiyat,yil,kisisayisi,saticiid) values (@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10,@p11)", baglanti);
            ekle1.Parameters.AddWithValue("@p1", otoMarka.Text);
            ekle1.Parameters.AddWithValue("@p2", otoModel.Text);
            ekle1.Parameters.AddWithValue("@p3", otoYakit.Text);
            ekle1.Parameters.AddWithValue("@p4", otoVites.Text);
            ekle1.Parameters.AddWithValue("@p5", otoRenk.Text);
            ekle1.Parameters.AddWithValue("@p6", otoTur.Text);
            ekle1.Parameters.AddWithValue("@p7", otoDurum.Text);
            ekle1.Parameters.AddWithValue("@p8", int.Parse(otoFiyat.Text));
            ekle1.Parameters.AddWithValue("@p9", int.Parse(otoYil.Text));
            ekle1.Parameters.AddWithValue("@p10",int.Parse(otoKisi.Text));
            ekle1.Parameters.AddWithValue("@p11",int.Parse(otoSatici.Text));
            ekle1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı");
        }

        private void otoSil_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand sil1 = new NpgsqlCommand("delete from arac where aracid=@p1", baglanti);
            sil1.Parameters.AddWithValue("@p1", int.Parse(silinecekArac.Text));
            sil1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Arac Silindi");

        }

        private void otoGüncel_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand guncelle1 = new NpgsqlCommand("update otomobil set fiyat=@p1 where aracid=@p2",baglanti);
            guncelle1.Parameters.AddWithValue("@p1", int.Parse(otoFiyat.Text));
            guncelle1.Parameters.AddWithValue("@p2", int.Parse(silinecekArac.Text));
            guncelle1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Fiyat Güncellendi");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            satici Satici = new satici();
            Satici.Show();
            this.Close();
        }
    }
}

