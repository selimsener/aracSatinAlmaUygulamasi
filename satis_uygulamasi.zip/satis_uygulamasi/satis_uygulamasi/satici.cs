﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace satis_uygulamasi
{
    public partial class satici : Form
    {
        public satici()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            otomobil Otomobil = new otomobil();
            Otomobil.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            motosiklet Motosiklet = new motosiklet();
            Motosiklet.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            minivan Minivan = new minivan();
            Minivan.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ticariarac TicariArac = new ticariarac();
            TicariArac.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            arazi Arazi = new arazi();
            Arazi.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            motor Motor = new motor();
            Motor.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            tekerlek Tekerlek = new tekerlek();
            Tekerlek.Show();
            this.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            jant Jant = new jant();
            Jant.Show();
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            yag Yag = new yag();
            Yag.Show();
            this.Hide();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            navigasyon Navigasyon = new navigasyon();
            Navigasyon.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            icekipman IcEkipman = new icekipman();
            IcEkipman.Show();
            this.Hide();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form1 anasayfa = new Form1();
            anasayfa.Show();
            this.Hide();
        }
    }
}
