﻿
namespace satis_uygulamasi
{
    partial class otomobil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.otoMarka = new System.Windows.Forms.TextBox();
            this.otoTur = new System.Windows.Forms.TextBox();
            this.otoDurum = new System.Windows.Forms.TextBox();
            this.otoSatici = new System.Windows.Forms.TextBox();
            this.otoRenk = new System.Windows.Forms.TextBox();
            this.otoVites = new System.Windows.Forms.TextBox();
            this.otoYakit = new System.Windows.Forms.TextBox();
            this.otoModel = new System.Windows.Forms.TextBox();
            this.otoKisi = new System.Windows.Forms.TextBox();
            this.otoYil = new System.Windows.Forms.TextBox();
            this.otoFiyat = new System.Windows.Forms.TextBox();
            this.otoListe = new System.Windows.Forms.Button();
            this.otoGüncel = new System.Windows.Forms.Button();
            this.otoSil = new System.Windows.Forms.Button();
            this.otoEkle = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.silinecekArac = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 13);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(793, 165);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(0, 195);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "Marka:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label5.Location = new System.Drawing.Point(279, 399);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 26);
            this.label5.TabIndex = 5;
            this.label5.Text = "Satıcı ID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label6.Location = new System.Drawing.Point(279, 276);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 26);
            this.label6.TabIndex = 6;
            this.label6.Text = "Fiyat:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label7.Location = new System.Drawing.Point(279, 236);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 26);
            this.label7.TabIndex = 7;
            this.label7.Text = "Durum:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label8.Location = new System.Drawing.Point(1, 356);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 26);
            this.label8.TabIndex = 8;
            this.label8.Text = "Renk:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label9.Location = new System.Drawing.Point(0, 275);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 26);
            this.label9.TabIndex = 9;
            this.label9.Text = "Yakıt:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label11.Location = new System.Drawing.Point(279, 317);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 26);
            this.label11.TabIndex = 11;
            this.label11.Text = "Yıl:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label12.Location = new System.Drawing.Point(279, 195);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 26);
            this.label12.TabIndex = 12;
            this.label12.Text = "Tür:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label13.Location = new System.Drawing.Point(279, 359);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 26);
            this.label13.TabIndex = 13;
            this.label13.Text = "Kişi Sayısı:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label14.Location = new System.Drawing.Point(1, 317);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(64, 26);
            this.label14.TabIndex = 14;
            this.label14.Text = "Vites:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label15.Location = new System.Drawing.Point(0, 236);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 26);
            this.label15.TabIndex = 15;
            this.label15.Text = "Model:";
            // 
            // otoMarka
            // 
            this.otoMarka.Location = new System.Drawing.Point(82, 199);
            this.otoMarka.Name = "otoMarka";
            this.otoMarka.Size = new System.Drawing.Size(162, 22);
            this.otoMarka.TabIndex = 16;
            // 
            // otoTur
            // 
            this.otoTur.Location = new System.Drawing.Point(398, 199);
            this.otoTur.Name = "otoTur";
            this.otoTur.Size = new System.Drawing.Size(162, 22);
            this.otoTur.TabIndex = 17;
            // 
            // otoDurum
            // 
            this.otoDurum.Location = new System.Drawing.Point(398, 240);
            this.otoDurum.Name = "otoDurum";
            this.otoDurum.Size = new System.Drawing.Size(162, 22);
            this.otoDurum.TabIndex = 18;
            // 
            // otoSatici
            // 
            this.otoSatici.Location = new System.Drawing.Point(398, 399);
            this.otoSatici.Name = "otoSatici";
            this.otoSatici.Size = new System.Drawing.Size(162, 22);
            this.otoSatici.TabIndex = 19;
            // 
            // otoRenk
            // 
            this.otoRenk.Location = new System.Drawing.Point(82, 359);
            this.otoRenk.Name = "otoRenk";
            this.otoRenk.Size = new System.Drawing.Size(162, 22);
            this.otoRenk.TabIndex = 20;
            // 
            // otoVites
            // 
            this.otoVites.Location = new System.Drawing.Point(82, 320);
            this.otoVites.Name = "otoVites";
            this.otoVites.Size = new System.Drawing.Size(162, 22);
            this.otoVites.TabIndex = 21;
            // 
            // otoYakit
            // 
            this.otoYakit.Location = new System.Drawing.Point(82, 279);
            this.otoYakit.Name = "otoYakit";
            this.otoYakit.Size = new System.Drawing.Size(162, 22);
            this.otoYakit.TabIndex = 22;
            // 
            // otoModel
            // 
            this.otoModel.Location = new System.Drawing.Point(82, 239);
            this.otoModel.Name = "otoModel";
            this.otoModel.Size = new System.Drawing.Size(162, 22);
            this.otoModel.TabIndex = 23;
            // 
            // otoKisi
            // 
            this.otoKisi.Location = new System.Drawing.Point(398, 360);
            this.otoKisi.Name = "otoKisi";
            this.otoKisi.Size = new System.Drawing.Size(162, 22);
            this.otoKisi.TabIndex = 25;
            // 
            // otoYil
            // 
            this.otoYil.Location = new System.Drawing.Point(398, 317);
            this.otoYil.Name = "otoYil";
            this.otoYil.Size = new System.Drawing.Size(162, 22);
            this.otoYil.TabIndex = 26;
            // 
            // otoFiyat
            // 
            this.otoFiyat.Location = new System.Drawing.Point(398, 280);
            this.otoFiyat.Name = "otoFiyat";
            this.otoFiyat.Size = new System.Drawing.Size(162, 22);
            this.otoFiyat.TabIndex = 27;
            // 
            // otoListe
            // 
            this.otoListe.BackColor = System.Drawing.SystemColors.GrayText;
            this.otoListe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.otoListe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.otoListe.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.otoListe.Location = new System.Drawing.Point(626, 227);
            this.otoListe.Name = "otoListe";
            this.otoListe.Size = new System.Drawing.Size(166, 34);
            this.otoListe.TabIndex = 28;
            this.otoListe.Text = "LİSTELE";
            this.otoListe.UseVisualStyleBackColor = false;
            this.otoListe.Click += new System.EventHandler(this.button1_Click);
            // 
            // otoGüncel
            // 
            this.otoGüncel.BackColor = System.Drawing.SystemColors.GrayText;
            this.otoGüncel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.otoGüncel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.otoGüncel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.otoGüncel.Location = new System.Drawing.Point(626, 347);
            this.otoGüncel.Name = "otoGüncel";
            this.otoGüncel.Size = new System.Drawing.Size(166, 34);
            this.otoGüncel.TabIndex = 29;
            this.otoGüncel.Text = "GÜNCELLE";
            this.otoGüncel.UseVisualStyleBackColor = false;
            this.otoGüncel.Click += new System.EventHandler(this.otoGüncel_Click);
            // 
            // otoSil
            // 
            this.otoSil.BackColor = System.Drawing.SystemColors.GrayText;
            this.otoSil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.otoSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.otoSil.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.otoSil.Location = new System.Drawing.Point(626, 307);
            this.otoSil.Name = "otoSil";
            this.otoSil.Size = new System.Drawing.Size(166, 34);
            this.otoSil.TabIndex = 30;
            this.otoSil.Text = "SİL";
            this.otoSil.UseVisualStyleBackColor = false;
            this.otoSil.Click += new System.EventHandler(this.otoSil_Click);
            // 
            // otoEkle
            // 
            this.otoEkle.BackColor = System.Drawing.SystemColors.GrayText;
            this.otoEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.otoEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.otoEkle.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.otoEkle.Location = new System.Drawing.Point(626, 267);
            this.otoEkle.Name = "otoEkle";
            this.otoEkle.Size = new System.Drawing.Size(166, 34);
            this.otoEkle.TabIndex = 31;
            this.otoEkle.Text = "EKLE";
            this.otoEkle.UseVisualStyleBackColor = false;
            this.otoEkle.Click += new System.EventHandler(this.otoEkle_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.GrayText;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.Location = new System.Drawing.Point(626, 387);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(166, 34);
            this.button5.TabIndex = 32;
            this.button5.Text = "GERİ";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label2.Location = new System.Drawing.Point(0, 396);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 26);
            this.label2.TabIndex = 33;
            this.label2.Text = "Araç ID:";
            // 
            // silinecekArac
            // 
            this.silinecekArac.Location = new System.Drawing.Point(82, 399);
            this.silinecekArac.Name = "silinecekArac";
            this.silinecekArac.Size = new System.Drawing.Size(162, 22);
            this.silinecekArac.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label3.Location = new System.Drawing.Point(7, 440);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(498, 22);
            this.label3.TabIndex = 35;
            this.label3.Text = "Silme işlemi için sadece \"Araç ID\" değeri girmeniz yeterlidir.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label4.Location = new System.Drawing.Point(8, 462);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(417, 22);
            this.label4.TabIndex = 36;
            this.label4.Text = "Güncelleme için \"Fiyat\" ve \"Araç ID\" değeri giriniz.";
            // 
            // otomobil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(817, 492);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.silinecekArac);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.otoEkle);
            this.Controls.Add(this.otoSil);
            this.Controls.Add(this.otoGüncel);
            this.Controls.Add(this.otoListe);
            this.Controls.Add(this.otoFiyat);
            this.Controls.Add(this.otoYil);
            this.Controls.Add(this.otoKisi);
            this.Controls.Add(this.otoModel);
            this.Controls.Add(this.otoYakit);
            this.Controls.Add(this.otoVites);
            this.Controls.Add(this.otoRenk);
            this.Controls.Add(this.otoSatici);
            this.Controls.Add(this.otoDurum);
            this.Controls.Add(this.otoTur);
            this.Controls.Add(this.otoMarka);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "otomobil";
            this.Text = "otomobil";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox otoMarka;
        private System.Windows.Forms.TextBox otoTur;
        private System.Windows.Forms.TextBox otoDurum;
        private System.Windows.Forms.TextBox otoSatici;
        private System.Windows.Forms.TextBox otoRenk;
        private System.Windows.Forms.TextBox otoVites;
        private System.Windows.Forms.TextBox otoYakit;
        private System.Windows.Forms.TextBox otoModel;
        private System.Windows.Forms.TextBox otoKisi;
        private System.Windows.Forms.TextBox otoYil;
        private System.Windows.Forms.TextBox otoFiyat;
        private System.Windows.Forms.Button otoListe;
        private System.Windows.Forms.Button otoGüncel;
        private System.Windows.Forms.Button otoSil;
        private System.Windows.Forms.Button otoEkle;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox silinecekArac;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}