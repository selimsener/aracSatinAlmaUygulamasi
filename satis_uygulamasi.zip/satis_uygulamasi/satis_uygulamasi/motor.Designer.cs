﻿
namespace satis_uygulamasi
{
    partial class motor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button5 = new System.Windows.Forms.Button();
            this.ekle = new System.Windows.Forms.Button();
            this.sil = new System.Windows.Forms.Button();
            this.listele = new System.Windows.Forms.Button();
            this.motorTarih = new System.Windows.Forms.TextBox();
            this.motorModel = new System.Windows.Forms.TextBox();
            this.motorHacim = new System.Windows.Forms.TextBox();
            this.aracParca = new System.Windows.Forms.TextBox();
            this.motorGuc = new System.Windows.Forms.TextBox();
            this.motorTur = new System.Windows.Forms.TextBox();
            this.motorMarka = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.aracID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.GrayText;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.Location = new System.Drawing.Point(607, 322);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(166, 34);
            this.button5.TabIndex = 62;
            this.button5.Text = "GERİ";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // ekle
            // 
            this.ekle.BackColor = System.Drawing.SystemColors.GrayText;
            this.ekle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ekle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ekle.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.ekle.Location = new System.Drawing.Point(607, 238);
            this.ekle.Name = "ekle";
            this.ekle.Size = new System.Drawing.Size(166, 34);
            this.ekle.TabIndex = 61;
            this.ekle.Text = "EKLE";
            this.ekle.UseVisualStyleBackColor = false;
            this.ekle.Click += new System.EventHandler(this.ekle_Click);
            // 
            // sil
            // 
            this.sil.BackColor = System.Drawing.SystemColors.GrayText;
            this.sil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sil.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.sil.Location = new System.Drawing.Point(607, 278);
            this.sil.Name = "sil";
            this.sil.Size = new System.Drawing.Size(166, 34);
            this.sil.TabIndex = 60;
            this.sil.Text = "SİL";
            this.sil.UseVisualStyleBackColor = false;
            this.sil.Click += new System.EventHandler(this.sil_Click);
            // 
            // listele
            // 
            this.listele.BackColor = System.Drawing.SystemColors.GrayText;
            this.listele.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.listele.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listele.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.listele.Location = new System.Drawing.Point(607, 198);
            this.listele.Name = "listele";
            this.listele.Size = new System.Drawing.Size(166, 34);
            this.listele.TabIndex = 58;
            this.listele.Text = "LİSTELE";
            this.listele.UseVisualStyleBackColor = false;
            this.listele.Click += new System.EventHandler(this.listele_Click);
            // 
            // motorTarih
            // 
            this.motorTarih.Location = new System.Drawing.Point(396, 281);
            this.motorTarih.Name = "motorTarih";
            this.motorTarih.Size = new System.Drawing.Size(162, 22);
            this.motorTarih.TabIndex = 57;
            // 
            // motorModel
            // 
            this.motorModel.Location = new System.Drawing.Point(80, 245);
            this.motorModel.Name = "motorModel";
            this.motorModel.Size = new System.Drawing.Size(162, 22);
            this.motorModel.TabIndex = 54;
            // 
            // motorHacim
            // 
            this.motorHacim.Location = new System.Drawing.Point(80, 285);
            this.motorHacim.Name = "motorHacim";
            this.motorHacim.Size = new System.Drawing.Size(162, 22);
            this.motorHacim.TabIndex = 53;
            // 
            // aracParca
            // 
            this.aracParca.Location = new System.Drawing.Point(149, 321);
            this.aracParca.Name = "aracParca";
            this.aracParca.Size = new System.Drawing.Size(93, 22);
            this.aracParca.TabIndex = 52;
            // 
            // motorGuc
            // 
            this.motorGuc.Location = new System.Drawing.Point(396, 241);
            this.motorGuc.Name = "motorGuc";
            this.motorGuc.Size = new System.Drawing.Size(162, 22);
            this.motorGuc.TabIndex = 49;
            // 
            // motorTur
            // 
            this.motorTur.Location = new System.Drawing.Point(396, 205);
            this.motorTur.Name = "motorTur";
            this.motorTur.Size = new System.Drawing.Size(162, 22);
            this.motorTur.TabIndex = 48;
            // 
            // motorMarka
            // 
            this.motorMarka.Location = new System.Drawing.Point(80, 205);
            this.motorMarka.Name = "motorMarka";
            this.motorMarka.Size = new System.Drawing.Size(162, 22);
            this.motorMarka.TabIndex = 47;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label15.Location = new System.Drawing.Point(-2, 242);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 26);
            this.label15.TabIndex = 46;
            this.label15.Text = "Model:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label14.Location = new System.Drawing.Point(277, 241);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 26);
            this.label14.TabIndex = 45;
            this.label14.Text = "Güç:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label12.Location = new System.Drawing.Point(277, 201);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 26);
            this.label12.TabIndex = 43;
            this.label12.Text = "Tür:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label9.Location = new System.Drawing.Point(-2, 281);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 26);
            this.label9.TabIndex = 41;
            this.label9.Text = "Hacim:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label7.Location = new System.Drawing.Point(-2, 318);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(145, 26);
            this.label7.TabIndex = 39;
            this.label7.Text = "Araç Parça ID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label6.Location = new System.Drawing.Point(277, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 26);
            this.label6.TabIndex = 38;
            this.label6.Text = "Tarih:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(-2, 201);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 26);
            this.label1.TabIndex = 36;
            this.label1.Text = "Marka:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(10, 19);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(793, 165);
            this.dataGridView1.TabIndex = 35;
            // 
            // aracID
            // 
            this.aracID.Location = new System.Drawing.Point(396, 322);
            this.aracID.Name = "aracID";
            this.aracID.Size = new System.Drawing.Size(162, 22);
            this.aracID.TabIndex = 63;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label2.Location = new System.Drawing.Point(277, 319);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 26);
            this.label2.TabIndex = 64;
            this.label2.Text = "Araç ID:";
            // 
            // motor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(819, 401);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.aracID);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.ekle);
            this.Controls.Add(this.sil);
            this.Controls.Add(this.listele);
            this.Controls.Add(this.motorTarih);
            this.Controls.Add(this.motorModel);
            this.Controls.Add(this.motorHacim);
            this.Controls.Add(this.aracParca);
            this.Controls.Add(this.motorGuc);
            this.Controls.Add(this.motorTur);
            this.Controls.Add(this.motorMarka);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "motor";
            this.Text = "motor";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button ekle;
        private System.Windows.Forms.Button sil;
        private System.Windows.Forms.Button listele;
        private System.Windows.Forms.TextBox motorTarih;
        private System.Windows.Forms.TextBox motorModel;
        private System.Windows.Forms.TextBox motorHacim;
        private System.Windows.Forms.TextBox aracParca;
        private System.Windows.Forms.TextBox motorGuc;
        private System.Windows.Forms.TextBox motorTur;
        private System.Windows.Forms.TextBox motorMarka;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox aracID;
        private System.Windows.Forms.Label label2;
    }
}