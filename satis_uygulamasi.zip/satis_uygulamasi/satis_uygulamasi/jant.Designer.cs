﻿
namespace satis_uygulamasi
{
    partial class jant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.aracID = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.ekle = new System.Windows.Forms.Button();
            this.sil = new System.Windows.Forms.Button();
            this.listele = new System.Windows.Forms.Button();
            this.jantTarih = new System.Windows.Forms.TextBox();
            this.jantModel = new System.Windows.Forms.TextBox();
            this.jantRenk = new System.Windows.Forms.TextBox();
            this.aracParca = new System.Windows.Forms.TextBox();
            this.jantGenislik = new System.Windows.Forms.TextBox();
            this.jantCap = new System.Windows.Forms.TextBox();
            this.jantMarka = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.jantTip = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label2.Location = new System.Drawing.Point(279, 312);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 26);
            this.label2.TabIndex = 85;
            this.label2.Text = "Araç ID:";
            // 
            // aracID
            // 
            this.aracID.Location = new System.Drawing.Point(398, 315);
            this.aracID.Name = "aracID";
            this.aracID.Size = new System.Drawing.Size(162, 22);
            this.aracID.TabIndex = 84;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.GrayText;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.Location = new System.Drawing.Point(609, 315);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(166, 34);
            this.button5.TabIndex = 83;
            this.button5.Text = "GERİ";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // ekle
            // 
            this.ekle.BackColor = System.Drawing.SystemColors.GrayText;
            this.ekle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ekle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ekle.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.ekle.Location = new System.Drawing.Point(609, 231);
            this.ekle.Name = "ekle";
            this.ekle.Size = new System.Drawing.Size(166, 34);
            this.ekle.TabIndex = 82;
            this.ekle.Text = "EKLE";
            this.ekle.UseVisualStyleBackColor = false;
            this.ekle.Click += new System.EventHandler(this.ekle_Click);
            // 
            // sil
            // 
            this.sil.BackColor = System.Drawing.SystemColors.GrayText;
            this.sil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sil.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.sil.Location = new System.Drawing.Point(609, 271);
            this.sil.Name = "sil";
            this.sil.Size = new System.Drawing.Size(166, 34);
            this.sil.TabIndex = 81;
            this.sil.Text = "SİL";
            this.sil.UseVisualStyleBackColor = false;
            this.sil.Click += new System.EventHandler(this.sil_Click);
            // 
            // listele
            // 
            this.listele.BackColor = System.Drawing.SystemColors.GrayText;
            this.listele.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.listele.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listele.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.listele.Location = new System.Drawing.Point(609, 191);
            this.listele.Name = "listele";
            this.listele.Size = new System.Drawing.Size(166, 34);
            this.listele.TabIndex = 80;
            this.listele.Text = "LİSTELE";
            this.listele.UseVisualStyleBackColor = false;
            this.listele.Click += new System.EventHandler(this.listele_Click);
            // 
            // jantTarih
            // 
            this.jantTarih.Location = new System.Drawing.Point(398, 274);
            this.jantTarih.Name = "jantTarih";
            this.jantTarih.Size = new System.Drawing.Size(162, 22);
            this.jantTarih.TabIndex = 79;
            // 
            // jantModel
            // 
            this.jantModel.Location = new System.Drawing.Point(82, 238);
            this.jantModel.Name = "jantModel";
            this.jantModel.Size = new System.Drawing.Size(162, 22);
            this.jantModel.TabIndex = 78;
            // 
            // jantRenk
            // 
            this.jantRenk.Location = new System.Drawing.Point(82, 278);
            this.jantRenk.Name = "jantRenk";
            this.jantRenk.Size = new System.Drawing.Size(162, 22);
            this.jantRenk.TabIndex = 77;
            // 
            // aracParca
            // 
            this.aracParca.Location = new System.Drawing.Point(284, 357);
            this.aracParca.Name = "aracParca";
            this.aracParca.Size = new System.Drawing.Size(135, 22);
            this.aracParca.TabIndex = 76;
            // 
            // jantGenislik
            // 
            this.jantGenislik.Location = new System.Drawing.Point(398, 234);
            this.jantGenislik.Name = "jantGenislik";
            this.jantGenislik.Size = new System.Drawing.Size(162, 22);
            this.jantGenislik.TabIndex = 75;
            // 
            // jantCap
            // 
            this.jantCap.Location = new System.Drawing.Point(398, 198);
            this.jantCap.Name = "jantCap";
            this.jantCap.Size = new System.Drawing.Size(162, 22);
            this.jantCap.TabIndex = 74;
            // 
            // jantMarka
            // 
            this.jantMarka.Location = new System.Drawing.Point(82, 198);
            this.jantMarka.Name = "jantMarka";
            this.jantMarka.Size = new System.Drawing.Size(162, 22);
            this.jantMarka.TabIndex = 73;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label15.Location = new System.Drawing.Point(0, 235);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 26);
            this.label15.TabIndex = 72;
            this.label15.Text = "Model:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label14.Location = new System.Drawing.Point(279, 234);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(94, 26);
            this.label14.TabIndex = 71;
            this.label14.Text = "Genişlik:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label12.Location = new System.Drawing.Point(279, 194);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 26);
            this.label12.TabIndex = 70;
            this.label12.Text = "Çap:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label9.Location = new System.Drawing.Point(0, 274);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 26);
            this.label9.TabIndex = 69;
            this.label9.Text = "Renk:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label7.Location = new System.Drawing.Point(99, 353);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(145, 26);
            this.label7.TabIndex = 68;
            this.label7.Text = "Araç Parça ID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label6.Location = new System.Drawing.Point(279, 275);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 26);
            this.label6.TabIndex = 67;
            this.label6.Text = "Tarih:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(0, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 26);
            this.label1.TabIndex = 66;
            this.label1.Text = "Marka:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(793, 165);
            this.dataGridView1.TabIndex = 65;
            // 
            // jantTip
            // 
            this.jantTip.Location = new System.Drawing.Point(82, 315);
            this.jantTip.Name = "jantTip";
            this.jantTip.Size = new System.Drawing.Size(162, 22);
            this.jantTip.TabIndex = 86;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label3.Location = new System.Drawing.Point(0, 311);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 26);
            this.label3.TabIndex = 87;
            this.label3.Text = "Tip:";
            // 
            // jant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(828, 399);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.jantTip);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.aracID);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.ekle);
            this.Controls.Add(this.sil);
            this.Controls.Add(this.listele);
            this.Controls.Add(this.jantTarih);
            this.Controls.Add(this.jantModel);
            this.Controls.Add(this.jantRenk);
            this.Controls.Add(this.aracParca);
            this.Controls.Add(this.jantGenislik);
            this.Controls.Add(this.jantCap);
            this.Controls.Add(this.jantMarka);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "jant";
            this.Text = "jant";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox aracID;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button ekle;
        private System.Windows.Forms.Button sil;
        private System.Windows.Forms.Button listele;
        private System.Windows.Forms.TextBox jantTarih;
        private System.Windows.Forms.TextBox jantModel;
        private System.Windows.Forms.TextBox jantRenk;
        private System.Windows.Forms.TextBox aracParca;
        private System.Windows.Forms.TextBox jantGenislik;
        private System.Windows.Forms.TextBox jantCap;
        private System.Windows.Forms.TextBox jantMarka;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox jantTip;
        private System.Windows.Forms.Label label3;
    }
}