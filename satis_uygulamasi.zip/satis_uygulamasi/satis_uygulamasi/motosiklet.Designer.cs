﻿
namespace satis_uygulamasi
{
    partial class motosiklet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.aracId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.motoEkle = new System.Windows.Forms.Button();
            this.otoSil = new System.Windows.Forms.Button();
            this.otoGüncel = new System.Windows.Forms.Button();
            this.otoListe = new System.Windows.Forms.Button();
            this.motoFiyat = new System.Windows.Forms.TextBox();
            this.motoYil = new System.Windows.Forms.TextBox();
            this.motoSilindir = new System.Windows.Forms.TextBox();
            this.motoModel = new System.Windows.Forms.TextBox();
            this.motoYakit = new System.Windows.Forms.TextBox();
            this.motoVites = new System.Windows.Forms.TextBox();
            this.motoRenk = new System.Windows.Forms.TextBox();
            this.motoSatici = new System.Windows.Forms.TextBox();
            this.motoDurum = new System.Windows.Forms.TextBox();
            this.motoZamanlama = new System.Windows.Forms.TextBox();
            this.motoMarka = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.motoSogutma = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label4.Location = new System.Drawing.Point(1, 492);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(417, 22);
            this.label4.TabIndex = 68;
            this.label4.Text = "Güncelleme için \"Fiyat\" ve \"Araç ID\" değeri giriniz.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label3.Location = new System.Drawing.Point(2, 514);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(498, 22);
            this.label3.TabIndex = 67;
            this.label3.Text = "Silme işlemi için sadece \"Araç ID\" değeri girmeniz yeterlidir.";
            // 
            // aracId
            // 
            this.aracId.Location = new System.Drawing.Point(82, 398);
            this.aracId.Name = "aracId";
            this.aracId.Size = new System.Drawing.Size(162, 22);
            this.aracId.TabIndex = 66;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label2.Location = new System.Drawing.Point(0, 395);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 26);
            this.label2.TabIndex = 65;
            this.label2.Text = "Araç ID:";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.GrayText;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.Location = new System.Drawing.Point(626, 386);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(166, 34);
            this.button5.TabIndex = 64;
            this.button5.Text = "GERİ";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // motoEkle
            // 
            this.motoEkle.BackColor = System.Drawing.SystemColors.GrayText;
            this.motoEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.motoEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.motoEkle.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.motoEkle.Location = new System.Drawing.Point(626, 266);
            this.motoEkle.Name = "motoEkle";
            this.motoEkle.Size = new System.Drawing.Size(166, 34);
            this.motoEkle.TabIndex = 63;
            this.motoEkle.Text = "EKLE";
            this.motoEkle.UseVisualStyleBackColor = false;
            this.motoEkle.Click += new System.EventHandler(this.otoEkle_Click);
            // 
            // otoSil
            // 
            this.otoSil.BackColor = System.Drawing.SystemColors.GrayText;
            this.otoSil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.otoSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.otoSil.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.otoSil.Location = new System.Drawing.Point(626, 306);
            this.otoSil.Name = "otoSil";
            this.otoSil.Size = new System.Drawing.Size(166, 34);
            this.otoSil.TabIndex = 62;
            this.otoSil.Text = "SİL";
            this.otoSil.UseVisualStyleBackColor = false;
            this.otoSil.Click += new System.EventHandler(this.otoSil_Click);
            // 
            // otoGüncel
            // 
            this.otoGüncel.BackColor = System.Drawing.SystemColors.GrayText;
            this.otoGüncel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.otoGüncel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.otoGüncel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.otoGüncel.Location = new System.Drawing.Point(626, 346);
            this.otoGüncel.Name = "otoGüncel";
            this.otoGüncel.Size = new System.Drawing.Size(166, 34);
            this.otoGüncel.TabIndex = 61;
            this.otoGüncel.Text = "GÜNCELLE";
            this.otoGüncel.UseVisualStyleBackColor = false;
            this.otoGüncel.Click += new System.EventHandler(this.otoGüncel_Click);
            // 
            // otoListe
            // 
            this.otoListe.BackColor = System.Drawing.SystemColors.GrayText;
            this.otoListe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.otoListe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.otoListe.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.otoListe.Location = new System.Drawing.Point(626, 226);
            this.otoListe.Name = "otoListe";
            this.otoListe.Size = new System.Drawing.Size(166, 34);
            this.otoListe.TabIndex = 60;
            this.otoListe.Text = "LİSTELE";
            this.otoListe.UseVisualStyleBackColor = false;
            this.otoListe.Click += new System.EventHandler(this.otoListe_Click);
            // 
            // motoFiyat
            // 
            this.motoFiyat.Location = new System.Drawing.Point(398, 279);
            this.motoFiyat.Name = "motoFiyat";
            this.motoFiyat.Size = new System.Drawing.Size(162, 22);
            this.motoFiyat.TabIndex = 59;
            // 
            // motoYil
            // 
            this.motoYil.Location = new System.Drawing.Point(398, 316);
            this.motoYil.Name = "motoYil";
            this.motoYil.Size = new System.Drawing.Size(162, 22);
            this.motoYil.TabIndex = 58;
            // 
            // motoSilindir
            // 
            this.motoSilindir.Location = new System.Drawing.Point(429, 358);
            this.motoSilindir.Name = "motoSilindir";
            this.motoSilindir.Size = new System.Drawing.Size(162, 22);
            this.motoSilindir.TabIndex = 57;
            // 
            // motoModel
            // 
            this.motoModel.Location = new System.Drawing.Point(82, 238);
            this.motoModel.Name = "motoModel";
            this.motoModel.Size = new System.Drawing.Size(162, 22);
            this.motoModel.TabIndex = 56;
            // 
            // motoYakit
            // 
            this.motoYakit.Location = new System.Drawing.Point(82, 278);
            this.motoYakit.Name = "motoYakit";
            this.motoYakit.Size = new System.Drawing.Size(162, 22);
            this.motoYakit.TabIndex = 55;
            // 
            // motoVites
            // 
            this.motoVites.Location = new System.Drawing.Point(82, 319);
            this.motoVites.Name = "motoVites";
            this.motoVites.Size = new System.Drawing.Size(162, 22);
            this.motoVites.TabIndex = 54;
            // 
            // motoRenk
            // 
            this.motoRenk.Location = new System.Drawing.Point(82, 358);
            this.motoRenk.Name = "motoRenk";
            this.motoRenk.Size = new System.Drawing.Size(162, 22);
            this.motoRenk.TabIndex = 53;
            // 
            // motoSatici
            // 
            this.motoSatici.Location = new System.Drawing.Point(398, 398);
            this.motoSatici.Name = "motoSatici";
            this.motoSatici.Size = new System.Drawing.Size(162, 22);
            this.motoSatici.TabIndex = 52;
            // 
            // motoDurum
            // 
            this.motoDurum.Location = new System.Drawing.Point(398, 239);
            this.motoDurum.Name = "motoDurum";
            this.motoDurum.Size = new System.Drawing.Size(162, 22);
            this.motoDurum.TabIndex = 51;
            // 
            // motoZamanlama
            // 
            this.motoZamanlama.Location = new System.Drawing.Point(256, 437);
            this.motoZamanlama.Name = "motoZamanlama";
            this.motoZamanlama.Size = new System.Drawing.Size(162, 22);
            this.motoZamanlama.TabIndex = 50;
            // 
            // motoMarka
            // 
            this.motoMarka.Location = new System.Drawing.Point(82, 198);
            this.motoMarka.Name = "motoMarka";
            this.motoMarka.Size = new System.Drawing.Size(162, 22);
            this.motoMarka.TabIndex = 49;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label15.Location = new System.Drawing.Point(0, 235);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 26);
            this.label15.TabIndex = 48;
            this.label15.Text = "Model:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label14.Location = new System.Drawing.Point(1, 316);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(64, 26);
            this.label14.TabIndex = 47;
            this.label14.Text = "Vites:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label13.Location = new System.Drawing.Point(279, 358);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(144, 26);
            this.label13.TabIndex = 46;
            this.label13.Text = "Silindir Sayısı:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label12.Location = new System.Drawing.Point(81, 437);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(169, 26);
            this.label12.TabIndex = 45;
            this.label12.Text = "Zamanlama Tipi:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label11.Location = new System.Drawing.Point(279, 316);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 26);
            this.label11.TabIndex = 44;
            this.label11.Text = "Yıl:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label9.Location = new System.Drawing.Point(0, 274);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 26);
            this.label9.TabIndex = 43;
            this.label9.Text = "Yakıt:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label8.Location = new System.Drawing.Point(1, 355);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 26);
            this.label8.TabIndex = 42;
            this.label8.Text = "Renk:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label7.Location = new System.Drawing.Point(279, 235);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 26);
            this.label7.TabIndex = 41;
            this.label7.Text = "Durum:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label6.Location = new System.Drawing.Point(279, 275);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 26);
            this.label6.TabIndex = 40;
            this.label6.Text = "Fiyat:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label5.Location = new System.Drawing.Point(279, 398);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 26);
            this.label5.TabIndex = 39;
            this.label5.Text = "Satıcı ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(0, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 26);
            this.label1.TabIndex = 38;
            this.label1.Text = "Marka:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(793, 165);
            this.dataGridView1.TabIndex = 37;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label10.Location = new System.Drawing.Point(279, 198);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 26);
            this.label10.TabIndex = 69;
            this.label10.Text = "Soğutma:";
            // 
            // motoSogutma
            // 
            this.motoSogutma.Location = new System.Drawing.Point(398, 201);
            this.motoSogutma.Name = "motoSogutma";
            this.motoSogutma.Size = new System.Drawing.Size(162, 22);
            this.motoSogutma.TabIndex = 70;
            // 
            // motosiklet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(825, 545);
            this.Controls.Add(this.motoSogutma);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.aracId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.motoEkle);
            this.Controls.Add(this.otoSil);
            this.Controls.Add(this.otoGüncel);
            this.Controls.Add(this.otoListe);
            this.Controls.Add(this.motoFiyat);
            this.Controls.Add(this.motoYil);
            this.Controls.Add(this.motoSilindir);
            this.Controls.Add(this.motoModel);
            this.Controls.Add(this.motoYakit);
            this.Controls.Add(this.motoVites);
            this.Controls.Add(this.motoRenk);
            this.Controls.Add(this.motoSatici);
            this.Controls.Add(this.motoDurum);
            this.Controls.Add(this.motoZamanlama);
            this.Controls.Add(this.motoMarka);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "motosiklet";
            this.Text = "motosiklet";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox aracId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button motoEkle;
        private System.Windows.Forms.Button otoSil;
        private System.Windows.Forms.Button otoGüncel;
        private System.Windows.Forms.Button otoListe;
        private System.Windows.Forms.TextBox motoFiyat;
        private System.Windows.Forms.TextBox motoYil;
        private System.Windows.Forms.TextBox motoSilindir;
        private System.Windows.Forms.TextBox motoModel;
        private System.Windows.Forms.TextBox motoYakit;
        private System.Windows.Forms.TextBox motoVites;
        private System.Windows.Forms.TextBox motoRenk;
        private System.Windows.Forms.TextBox motoSatici;
        private System.Windows.Forms.TextBox motoDurum;
        private System.Windows.Forms.TextBox motoZamanlama;
        private System.Windows.Forms.TextBox motoMarka;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox motoSogutma;
    }
}