﻿
namespace satis_uygulamasi
{
    partial class icekipman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.aracID = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.ekle = new System.Windows.Forms.Button();
            this.sil = new System.Windows.Forms.Button();
            this.listele = new System.Windows.Forms.Button();
            this.ieTarih = new System.Windows.Forms.TextBox();
            this.ieModel = new System.Windows.Forms.TextBox();
            this.urunAdi = new System.Windows.Forms.TextBox();
            this.aracParca = new System.Windows.Forms.TextBox();
            this.urunOzel = new System.Windows.Forms.TextBox();
            this.ieMarka = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label2.Location = new System.Drawing.Point(279, 239);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 26);
            this.label2.TabIndex = 85;
            this.label2.Text = "Araç ID:";
            // 
            // aracID
            // 
            this.aracID.Location = new System.Drawing.Point(362, 238);
            this.aracID.Name = "aracID";
            this.aracID.Size = new System.Drawing.Size(162, 22);
            this.aracID.TabIndex = 84;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.GrayText;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.Location = new System.Drawing.Point(609, 315);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(166, 34);
            this.button5.TabIndex = 83;
            this.button5.Text = "GERİ";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // ekle
            // 
            this.ekle.BackColor = System.Drawing.SystemColors.GrayText;
            this.ekle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ekle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ekle.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.ekle.Location = new System.Drawing.Point(609, 231);
            this.ekle.Name = "ekle";
            this.ekle.Size = new System.Drawing.Size(166, 34);
            this.ekle.TabIndex = 82;
            this.ekle.Text = "EKLE";
            this.ekle.UseVisualStyleBackColor = false;
            this.ekle.Click += new System.EventHandler(this.ekle_Click);
            // 
            // sil
            // 
            this.sil.BackColor = System.Drawing.SystemColors.GrayText;
            this.sil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sil.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.sil.Location = new System.Drawing.Point(609, 271);
            this.sil.Name = "sil";
            this.sil.Size = new System.Drawing.Size(166, 34);
            this.sil.TabIndex = 81;
            this.sil.Text = "SİL";
            this.sil.UseVisualStyleBackColor = false;
            this.sil.Click += new System.EventHandler(this.sil_Click);
            // 
            // listele
            // 
            this.listele.BackColor = System.Drawing.SystemColors.GrayText;
            this.listele.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.listele.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listele.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.listele.Location = new System.Drawing.Point(609, 191);
            this.listele.Name = "listele";
            this.listele.Size = new System.Drawing.Size(166, 34);
            this.listele.TabIndex = 80;
            this.listele.Text = "LİSTELE";
            this.listele.UseVisualStyleBackColor = false;
            this.listele.Click += new System.EventHandler(this.listele_Click);
            // 
            // ieTarih
            // 
            this.ieTarih.Location = new System.Drawing.Point(362, 279);
            this.ieTarih.Name = "ieTarih";
            this.ieTarih.Size = new System.Drawing.Size(162, 22);
            this.ieTarih.TabIndex = 79;
            // 
            // ieModel
            // 
            this.ieModel.Location = new System.Drawing.Point(82, 238);
            this.ieModel.Name = "ieModel";
            this.ieModel.Size = new System.Drawing.Size(162, 22);
            this.ieModel.TabIndex = 78;
            // 
            // urunAdi
            // 
            this.urunAdi.Location = new System.Drawing.Point(107, 278);
            this.urunAdi.Name = "urunAdi";
            this.urunAdi.Size = new System.Drawing.Size(137, 22);
            this.urunAdi.TabIndex = 77;
            // 
            // aracParca
            // 
            this.aracParca.Location = new System.Drawing.Point(265, 322);
            this.aracParca.Name = "aracParca";
            this.aracParca.Size = new System.Drawing.Size(167, 22);
            this.aracParca.TabIndex = 76;
            // 
            // urunOzel
            // 
            this.urunOzel.Location = new System.Drawing.Point(362, 203);
            this.urunOzel.Name = "urunOzel";
            this.urunOzel.Size = new System.Drawing.Size(162, 22);
            this.urunOzel.TabIndex = 74;
            // 
            // ieMarka
            // 
            this.ieMarka.Location = new System.Drawing.Point(82, 203);
            this.ieMarka.Name = "ieMarka";
            this.ieMarka.Size = new System.Drawing.Size(162, 22);
            this.ieMarka.TabIndex = 73;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label15.Location = new System.Drawing.Point(0, 239);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 26);
            this.label15.TabIndex = 72;
            this.label15.Text = "Model:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label12.Location = new System.Drawing.Point(279, 203);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 26);
            this.label12.TabIndex = 70;
            this.label12.Text = "Özellik:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label9.Location = new System.Drawing.Point(0, 279);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 26);
            this.label9.TabIndex = 69;
            this.label9.Text = "Ürün Adı:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label7.Location = new System.Drawing.Point(114, 319);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(145, 26);
            this.label7.TabIndex = 68;
            this.label7.Text = "Araç Parça ID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label6.Location = new System.Drawing.Point(279, 279);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 26);
            this.label6.TabIndex = 67;
            this.label6.Text = "Tarih:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(0, 199);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 26);
            this.label1.TabIndex = 66;
            this.label1.Text = "Marka:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(793, 165);
            this.dataGridView1.TabIndex = 65;
            // 
            // icekipman
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(822, 368);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.aracID);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.ekle);
            this.Controls.Add(this.sil);
            this.Controls.Add(this.listele);
            this.Controls.Add(this.ieTarih);
            this.Controls.Add(this.ieModel);
            this.Controls.Add(this.urunAdi);
            this.Controls.Add(this.aracParca);
            this.Controls.Add(this.urunOzel);
            this.Controls.Add(this.ieMarka);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "icekipman";
            this.Text = "icekipman";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox aracID;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button ekle;
        private System.Windows.Forms.Button sil;
        private System.Windows.Forms.Button listele;
        private System.Windows.Forms.TextBox ieTarih;
        private System.Windows.Forms.TextBox ieModel;
        private System.Windows.Forms.TextBox urunAdi;
        private System.Windows.Forms.TextBox aracParca;
        private System.Windows.Forms.TextBox urunOzel;
        private System.Windows.Forms.TextBox ieMarka;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}